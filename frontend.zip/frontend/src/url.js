export const URL=import.meta.env.VITE_URL
export const IF=import.meta.env.VITE_IF
